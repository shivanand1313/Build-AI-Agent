"""
PDF Reader — v2

Two reading modes:
  smart_read(url)  → first 3 + middle + last 2 pages (~7000 chars)
                     Used by rank_papers to quickly score relevance.
                     Fast enough to run on all ~20 candidate papers.

  full_read(url)   → ALL pages, trimmed to 14000 chars
                     Used by read_papers on the top-K selected papers only.
                     The LLM gets as much context as possible for extraction.

Fallback chain for both modes:
  1. pdfplumber (best quality)
  2. PyMuPDF / fitz (faster, handles more corruption)
  3. None → caller uses abstract text instead
"""

import io
import requests
from typing import Optional, List

try:
    import pdfplumber
    PDFPLUMBER_OK = True
except ImportError:
    PDFPLUMBER_OK = False
    print("WARNING: pdfplumber not installed → pip install pdfplumber")

try:
    import fitz   # PyMuPDF
    FITZ_OK = True
except ImportError:
    FITZ_OK = False

HEADERS = {'User-Agent': 'Mozilla/5.0 (aerospace-research-bot; academic use)'}
FETCH_TIMEOUT = 30


# ── Public API ────────────────────────────────────────────────────────────────

def smart_read(pdf_url: str) -> Optional[str]:
    """
    Fetch PDF and extract only the high-signal pages:
      Pages 0-2  → Abstract, Introduction, Problem statement
      Middle 2   → Methods (usually pages n/2, n/2+1)
      Last 2     → Conclusion, Limitations, References header

    Returns extracted text trimmed to 7000 chars, or None on failure.
    Used for relevance scoring of all candidate papers.
    """
    pdf_bytes = _fetch_pdf(pdf_url)
    if not pdf_bytes:
        return None

    if PDFPLUMBER_OK:
        text = _plumber_extract(pdf_bytes, mode='smart')
    elif FITZ_OK:
        text = _fitz_extract(pdf_bytes, mode='smart')
    else:
        return None

    return _trim(text, max_chars=7000)


def full_read(pdf_url: str) -> Optional[str]:
    """
    Fetch PDF and extract ALL pages.
    Returns text trimmed to 14000 chars (fits llama3.2 context with room for prompt).
    Used for the selected top-K papers before structured extraction.
    """
    pdf_bytes = _fetch_pdf(pdf_url)
    if not pdf_bytes:
        return None

    if PDFPLUMBER_OK:
        text = _plumber_extract(pdf_bytes, mode='full')
    elif FITZ_OK:
        text = _fitz_extract(pdf_bytes, mode='full')
    else:
        return None

    return _trim(text, max_chars=14000)


# ── Internals ─────────────────────────────────────────────────────────────────

def _fetch_pdf(url: str) -> Optional[bytes]:
    if not url:
        return None
    try:
        r = requests.get(url, headers=HEADERS, timeout=FETCH_TIMEOUT)
        r.raise_for_status()
        content_type = r.headers.get('Content-Type', '')
        # Verify it's actually a PDF
        if 'pdf' not in content_type.lower() and not r.content[:4] == b'%PDF':
            print(f"  [PDF] Not a PDF ({content_type[:30]}): {url[:60]}")
            return None
        return r.content
    except requests.exceptions.Timeout:
        print(f"  [PDF] Timeout: {url[:70]}")
        return None
    except requests.exceptions.HTTPError as e:
        print(f"  [PDF] HTTP {e.response.status_code}: {url[:70]}")
        return None
    except Exception as e:
        print(f"  [PDF] Fetch error: {e}")
        return None


def _select_pages(total: int, mode: str) -> List[int]:
    """Return 0-indexed page numbers to extract."""
    if mode == 'full':
        return list(range(total))

    # smart mode: first 3 + middle 2 + last 2
    pages = list(range(min(3, total)))
    if total > 6:
        mid = total // 2
        pages += [mid, min(mid + 1, total - 1)]
    if total > 4:
        tail = max(3, total - 2)
        pages += list(range(tail, total))
    return sorted(set(pages))


def _plumber_extract(pdf_bytes: bytes, mode: str) -> Optional[str]:
    try:
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            pages_to_read = _select_pages(len(pdf.pages), mode)
            sections = []
            for i in pages_to_read:
                text = pdf.pages[i].extract_text()
                if text and text.strip():
                    sections.append(f"[Page {i+1}]\n{text.strip()}")
            return "\n\n".join(sections) if sections else None
    except Exception as e:
        print(f"  [pdfplumber] Error: {e}")
        return None


def _fitz_extract(pdf_bytes: bytes, mode: str) -> Optional[str]:
    try:
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        pages_to_read = _select_pages(len(doc), mode)
        sections = []
        for i in pages_to_read:
            text = doc[i].get_text()
            if text and text.strip():
                sections.append(f"[Page {i+1}]\n{text.strip()}")
        doc.close()
        return "\n\n".join(sections) if sections else None
    except Exception as e:
        print(f"  [fitz] Error: {e}")
        return None


def _trim(text: Optional[str], max_chars: int) -> Optional[str]:
    """Trim from the middle to preserve start and end."""
    if not text:
        return None
    if len(text) <= max_chars:
        return text
    half = max_chars // 2
    return text[:half] + "\n\n[...middle sections omitted...]\n\n" + text[-half:]
