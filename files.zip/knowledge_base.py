"""
Aerospace Knowledge Base — v2

Changes:
  - paper_summary field (150-250 word paragraph) stored + returned
  - clear() fully resets the collection
  - get_all() returns links + summary for inspect display
  - Metadata value safety: truncate long strings to avoid ChromaDB limit
"""

import json
from datetime import datetime
from typing import List, Dict, Optional

import chromadb
from chromadb.utils import embedding_functions


class AerospaceKnowledgeBase:

    def __init__(self, persist_path: str = "./aerospace_kb"):
        self.client = chromadb.PersistentClient(path=persist_path)
        self.embedding_fn = embedding_functions.DefaultEmbeddingFunction()
        self._ensure_collection()

    def _ensure_collection(self):
        self.papers = self.client.get_or_create_collection(
            name="aerospace_papers",
            embedding_function=self.embedding_fn,
            metadata={"hnsw:space": "cosine"}
        )

    # ── Write ─────────────────────────────────────────────────────────────────

    def store_paper(self, paper: dict) -> bool:
        doc_text = self._build_document_text(paper)
        metadata = self._build_metadata(paper)
        paper_id = str(paper.get('paper_id') or paper.get('title', 'unknown')[:50])

        try:
            self.papers.upsert(
                ids=[paper_id],
                documents=[doc_text],
                metadatas=[metadata]
            )
            return True
        except Exception as e:
            print(f"  [KB] Store failed for '{paper.get('title', '?')[:40]}': {e}")
            return False

    def store_papers_batch(self, papers: List[dict]) -> int:
        return sum(1 for p in papers if self.store_paper(p))

    # ── Read ──────────────────────────────────────────────────────────────────

    def query(self, query_text: str, n_results: int = 5) -> List[Dict]:
        if self.papers.count() == 0:
            return []
        results = self.papers.query(
            query_texts=[query_text],
            n_results=min(n_results, self.papers.count())
        )
        return self._unpack_results(results)

    def query_by_constraint(self, constraint_keywords: List[str], n_results: int = 5) -> List[Dict]:
        query = f"constraints requirements limitations: {', '.join(constraint_keywords)}"
        return self.query(query, n_results)

    def get_all(self) -> List[Dict]:
        if self.papers.count() == 0:
            return []
        raw = self.papers.get(include=['documents', 'metadatas'])
        return [self._deserialize_metadata(m) for m in raw.get('metadatas', [])]

    def count(self) -> int:
        return self.papers.count()

    # ── Delete ────────────────────────────────────────────────────────────────

    def clear(self):
        """
        Delete ALL papers from the knowledge base and reset the collection.
        Equivalent of: rm -rf aerospace_kb && start fresh.
        """
        try:
            self.client.delete_collection("aerospace_papers")
        except Exception:
            pass
        self._ensure_collection()
        print("  [KB] Knowledge base cleared.")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_document_text(self, paper: dict) -> str:
        """Text that gets embedded — ordering matters for search relevance."""
        parts = [
            f"Title: {paper.get('title', '')}",
            f"Problem: {paper.get('problem_addressed', '')}",
            f"Method: {paper.get('proposed_method', '')}",
            f"Results: {paper.get('results_metrics', '')}",
            f"Constraints: {', '.join(paper.get('constraints', []))}",
            f"Assumptions: {', '.join(paper.get('key_assumptions', []))}",
            f"Summary: {paper.get('paper_summary', '')}",
            f"Abstract: {paper.get('abstract', '')[:400]}",
        ]
        return "\n".join(p for p in parts if p.split(': ', 1)[-1].strip())

    def _build_metadata(self, paper: dict) -> dict:
        """Flat metadata dict — all values must be str/int/float/bool."""
        def safe_str(v, limit=500):
            return str(v or '')[:limit]

        return {
            'title':            safe_str(paper.get('title'), 300),
            'authors':          json.dumps(paper.get('authors', []))[:500],
            'year':             safe_str(paper.get('year')),
            'source':           safe_str(paper.get('source')),
            'paper_id':         safe_str(paper.get('paper_id')),
            'pdf_url':          safe_str(paper.get('pdf_url'), 500),
            'web_url':          safe_str(paper.get('web_url'), 500),
            'problem_addressed': safe_str(paper.get('problem_addressed')),
            'proposed_method':   safe_str(paper.get('proposed_method')),
            'results_metrics':   safe_str(paper.get('results_metrics')),
            'constraints':       json.dumps(paper.get('constraints', []))[:500],
            'key_assumptions':   json.dumps(paper.get('key_assumptions', []))[:500],
            'abstract':          safe_str(paper.get('abstract'), 800),
            'paper_summary':     safe_str(paper.get('paper_summary'), 1500),
            'stored_at':         datetime.now().isoformat()
        }

    def _unpack_results(self, results: dict) -> List[Dict]:
        metadatas = results.get('metadatas', [[]])[0]
        distances = results.get('distances', [[]])[0]
        out = []
        for meta, dist in zip(metadatas, distances):
            paper = self._deserialize_metadata(meta)
            paper['relevance_score'] = round(1 - dist, 3)
            out.append(paper)
        return out

    def _deserialize_metadata(self, meta: dict) -> dict:
        paper = dict(meta)
        for field in ['authors', 'constraints', 'key_assumptions']:
            try:
                paper[field] = json.loads(paper.get(field, '[]'))
            except (json.JSONDecodeError, TypeError):
                paper[field] = []
        return paper
