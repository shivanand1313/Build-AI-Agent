"""
Literature Scout — Entry Point v2

Commands:
  python run.py                           Run default aerospace problem
  python run.py --query "your problem"   Run custom problem
  python run.py --inspect                See all papers in KB with links + summaries
  python run.py --query-kb "search"      Semantic search over KB
  python run.py --clear                  ⚠ Delete EVERYTHING from KB (irreversible)
  python run.py --clear --confirm        Required flag for --clear (safety)
"""

import argparse
import textwrap
from graph import build_scout_graph
from knowledge_base import AerospaceKnowledgeBase
from state import ScoutState


# ── Run ───────────────────────────────────────────────────────────────────────

def run_scout(problem_statement: str) -> ScoutState:
    graph = build_scout_graph()

    initial: ScoutState = {
        'problem_statement': problem_statement.strip(),
        'problem_summary': '',
        'refined_problem': '',
        'keywords': [],
        'search_queries': [],
        'raw_papers': [],
        'top_papers': [],
        'papers_to_read': [],
        'papers_read': [],
        'extracted_papers': [],
        'citation_seeds': [],
        'citation_papers': [],
        'citation_round': 0,
        'stored_count': 0,
        'messages': []
    }

    final = graph.invoke(initial)

    # ── Final summary ─────────────────────────────────────────────────
    print(f"\n{'═'*65}")
    print("  SCOUT COMPLETE")
    print(f"{'─'*65}")
    print(f"  Refined problem: {final.get('refined_problem', 'N/A')}")
    print(f"  Keywords:        {', '.join(final.get('keywords', []))}")
    print(f"\n  Papers found:     {len(final.get('raw_papers', []))}")
    print(f"  Top papers read:  {len(final.get('papers_read', []))}")
    print(f"  Citation papers:  {len(final.get('citation_papers', []))}")
    print(f"  Extracted:        {len(final.get('extracted_papers', []))}")
    print(f"  Stored to KB:     {final.get('stored_count', 0)}")
    print(f"\n  Run 'python run.py --inspect' to view all papers with links")
    print(f"{'═'*65}\n")

    return final


# ── Inspect ───────────────────────────────────────────────────────────────────

def inspect_kb():
    """
    Print all papers in ChromaDB with:
      - Title, year, source
      - PDF link + web link (for user verification)
      - Problem addressed / method
      - 150-250 word paragraph summary
      - Constraints list
    """
    kb = AerospaceKnowledgeBase()
    papers = kb.get_all()

    print(f"\n{'═'*70}")
    print(f"  KNOWLEDGE BASE — {len(papers)} paper(s) stored")
    print(f"{'═'*70}")

    if not papers:
        print("\n  (empty — run the scout first with: python run.py)")
        return

    for i, p in enumerate(papers, 1):
        title = p.get('title', 'Unknown')
        year = p.get('year', 'n.d.')
        source = p.get('source', '?')
        pdf_url = p.get('pdf_url', '')
        web_url = p.get('web_url', '')

        print(f"\n  ┌─ [{i}] {title}")
        print(f"  │  Year: {year}  |  Source: {source}")

        # Links
        if web_url:
            print(f"  │  🔗 Read online: {web_url}")
        if pdf_url:
            print(f"  │  📄 PDF:         {pdf_url}")

        # Core fields
        print(f"  │")
        print(f"  │  Problem:  {p.get('problem_addressed', 'N/A')[:90]}")
        print(f"  │  Method:   {p.get('proposed_method', 'N/A')[:90]}")
        print(f"  │  Results:  {p.get('results_metrics', 'N/A')[:90]}")

        # Constraints
        constraints = p.get('constraints', [])
        if constraints:
            print(f"  │")
            print(f"  │  Constraints:")
            for c in constraints[:3]:
                print(f"  │    • {c[:85]}")

        # Paragraph summary
        summary = p.get('paper_summary', '')
        if summary:
            print(f"  │")
            print(f"  │  Summary:")
            # Wrap at 70 chars, indent each line
            wrapped = textwrap.fill(summary, width=68)
            for line in wrapped.splitlines():
                print(f"  │    {line}")

        print(f"  └{'─'*66}")

    print(f"\n  Total: {len(papers)} papers in knowledge base")
    print(f"{'═'*70}\n")


# ── KB Search ─────────────────────────────────────────────────────────────────

def query_kb(search_term: str, n_results: int = 5):
    kb = AerospaceKnowledgeBase()
    results = kb.query(search_term, n_results=n_results)

    print(f"\n{'═'*65}")
    print(f"  KB SEARCH: '{search_term}'")
    print(f"{'─'*65}")

    if not results:
        print("  No results — KB may be empty. Run: python run.py")
        return

    for i, p in enumerate(results, 1):
        score = p.get('relevance_score', 0)
        print(f"\n  [{i}] (relevance: {score:.3f}) {p.get('title', '?')}")
        if p.get('web_url'):
            print(f"       🔗 {p['web_url']}")
        print(f"       {p.get('problem_addressed', 'N/A')[:90]}")
        summary = p.get('paper_summary', '')
        if summary:
            print(f"       {summary[:180]}...")

    print(f"\n{'═'*65}\n")


# ── Clear ─────────────────────────────────────────────────────────────────────

def clear_kb(confirmed: bool):
    """
    Deletes ALL papers from ChromaDB.
    Requires --confirm flag to prevent accidental deletion.
    """
    if not confirmed:
        print("\n  ⚠  --clear requires --confirm to prevent accidental deletion.")
        print("     Run: python run.py --clear --confirm")
        return

    kb = AerospaceKnowledgeBase()
    count_before = kb.count()
    kb.clear()
    print(f"\n  ✓ Knowledge base cleared. ({count_before} papers deleted)")
    print(f"  Run 'python run.py' to repopulate.\n")


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Literature Scout — Aerospace Research Automation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
            Examples:
              python run.py                                        # Default harness routing problem
              python run.py --query "defect detection in CFRP"    # Custom problem
              python run.py --inspect                             # View KB with links + summaries
              python run.py --query-kb "mesh generation CFD"      # Semantic search
              python run.py --clear --confirm                     # Delete all KB data
        """)
    )
    parser.add_argument('--query',     type=str,             help="Problem statement to research")
    parser.add_argument('--inspect',   action='store_true',  help="Inspect KB contents")
    parser.add_argument('--query-kb',  type=str,             help="Semantic search over KB")
    parser.add_argument('--clear',     action='store_true',  help="Delete all KB data")
    parser.add_argument('--confirm',   action='store_true',  help="Confirm destructive operations")
    args = parser.parse_args()

    if args.clear:
        clear_kb(confirmed=args.confirm)

    elif args.inspect:
        inspect_kb()

    elif args.query_kb:
        query_kb(args.query_kb)

    else:
        problem = args.query or """
        Automated wire harness routing optimisation in aircraft fuselage assembly.
        Minimise total wire length while satisfying electrical separation requirements
        between power, signal, and coaxial bundles, avoiding structural interference,
        and meeting aerospace standard AS50881 constraints on bend radius and clamp spacing.
        """
        run_scout(problem)
