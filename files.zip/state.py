"""
State definitions for the Literature Scout Agent — v2.

Annotated[List, operator.add]  → LangGraph MERGES each node's output in
Plain List                      → REPLACED each update (current-batch queues)
"""

import operator
from typing import TypedDict, List, Optional, Annotated


class Paper(TypedDict):
    paper_id: str
    title: str
    authors: List[str]
    abstract: str
    year: Optional[int]
    pdf_url: Optional[str]
    web_url: Optional[str]          # Human link: arxiv.org/abs/... or S2 page
    source: str                     # "arxiv" | "semantic_scholar" | "semantic_scholar_reference"
    s2_id: Optional[str]            # Must be present for citation following
    full_text: Optional[str]
    relevance_score: Optional[float]  # 1-10, set by rank_papers


class ExtractedPaper(TypedDict):
    """
    Written to ChromaDB. Schema is FIXED — Feasibility Critic reads these
    exact field names. Do not rename or remove fields.
    """
    paper_id: str
    title: str
    authors: List[str]
    year: Optional[int]
    source: str
    abstract: str
    pdf_url: Optional[str]          # Direct PDF link
    web_url: Optional[str]          # Browse link for user inspection
    problem_addressed: str
    proposed_method: str
    key_assumptions: List[str]
    results_metrics: str
    constraints: List[str]
    paper_summary: str              # 150-250 word paragraph for user display in inspect


class ScoutState(TypedDict):
    # Input
    problem_statement: str

    # Node 1 — generate_queries
    problem_summary: str            # 3-4 sentence understanding of the problem
    refined_problem: str            # Concise restatement used for all downstream work
    keywords: List[str]             # Domain keywords
    search_queries: List[str]       # 4 angle-specific queries

    # Node 2 — search_papers
    raw_papers: Annotated[List[Paper], operator.add]

    # Node 3 — rank_papers
    top_papers: List[Paper]         # Ranked top-K for full PDF read
    papers_to_read: List[Paper]     # Current batch queue (replaced each round)

    # Node 4 — read_papers
    papers_read: Annotated[List[Paper], operator.add]

    # Node 5 — extract_structured
    extracted_papers: Annotated[List[ExtractedPaper], operator.add]
    citation_seeds: List[str]       # S2 IDs fed to follow_citations

    # Node 6 — follow_citations
    citation_papers: Annotated[List[Paper], operator.add]
    citation_round: int             # Stops loop: 0 → follow, 1 → skip

    # Node 7 — store_to_kb
    stored_count: int

    # Audit log
    messages: Annotated[List[str], operator.add]
