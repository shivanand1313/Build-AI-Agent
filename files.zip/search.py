"""
Search tools: arxiv API + Semantic Scholar API — v2

Rate limiting fixes:
  arxiv  — Client configured with delay_seconds=3.0 + num_retries=5
            (the library auto-waits between requests)
  S2     — exponential backoff decorator: 3 attempts, 2s/8s/30s waits
            on HTTP 429; separate sleep between every call
"""

import time
import functools
import requests
from typing import List, Dict, Optional

try:
    import arxiv
    ARXIV_AVAILABLE = True
except ImportError:
    ARXIV_AVAILABLE = False
    print("WARNING: arxiv package not installed → pip install arxiv")


# ── Rate-limit decorator for S2 ──────────────────────────────────────────────

def s2_retry(max_attempts: int = 3, base_wait: float = 2.0):
    """
    Exponential-backoff retry decorator for Semantic Scholar API calls.
    Retries on 429 (rate limit) and 5xx server errors.
    Raises on 4xx client errors (bad query, missing paper) without retry.
    """
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            for attempt in range(1, max_attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except requests.exceptions.HTTPError as e:
                    status = e.response.status_code
                    if status == 429 or status >= 500:
                        wait = base_wait * (4 ** (attempt - 1))   # 2s, 8s, 32s
                        print(f"  [S2] HTTP {status} — waiting {wait:.0f}s (attempt {attempt}/{max_attempts})")
                        time.sleep(wait)
                        if attempt == max_attempts:
                            return []
                    else:
                        # 4xx other than 429 → won't improve on retry
                        print(f"  [S2] HTTP {status} — skipping (not retryable)")
                        return []
                except requests.exceptions.Timeout:
                    wait = base_wait * attempt
                    print(f"  [S2] Timeout — waiting {wait:.0f}s (attempt {attempt}/{max_attempts})")
                    time.sleep(wait)
                    if attempt == max_attempts:
                        return []
                except Exception as e:
                    print(f"  [S2] Unexpected error: {e}")
                    return []
        return wrapper
    return decorator


# ── arxiv ────────────────────────────────────────────────────────────────────

def search_arxiv(query: str, max_results: int = 5) -> List[Dict]:
    """
    Search arxiv.
    Client is configured with delay_seconds=3.0 so it never hammers the API.
    num_retries=5 handles transient 429s automatically inside the library.
    """
    if not ARXIV_AVAILABLE:
        return []

    try:
        client = arxiv.Client(
            delay_seconds=3.0,   # Wait 3s between every arxiv request
            num_retries=5        # Auto-retry on 429 / server errors
        )
        search = arxiv.Search(
            query=query,
            max_results=max_results,
            sort_by=arxiv.SortCriterion.Relevance
        )

        papers = []
        for result in client.results(search):
            arxiv_id = result.get_short_id()
            papers.append({
                'paper_id': arxiv_id,
                'title': result.title,
                'authors': [a.name for a in result.authors],
                'abstract': result.summary.replace('\n', ' '),
                'year': result.published.year if result.published else None,
                'pdf_url': result.pdf_url,
                'web_url': f"https://arxiv.org/abs/{arxiv_id}",
                'source': 'arxiv',
                's2_id': None,      # Resolved later by resolve_s2_ids()
                'full_text': None,
                'relevance_score': None
            })
        return papers

    except Exception as e:
        print(f"  [arxiv] Search failed for '{query[:50]}': {e}")
        return []


@s2_retry(max_attempts=3, base_wait=2.0)
def search_semantic_scholar(query: str, max_results: int = 5) -> List[Dict]:
    """
    Search Semantic Scholar Graph API.
    Decorated with exponential backoff retry.
    """
    url = "https://api.semanticscholar.org/graph/v1/paper/search"
    params = {
        'query': query,
        'limit': max_results,
        'fields': 'paperId,title,authors,year,abstract,openAccessPdf,externalIds,url'
    }
    response = requests.get(url, params=params, timeout=15)
    response.raise_for_status()
    data = response.json()

    papers = []
    for p in data.get('data', []):
        pdf_url = _resolve_pdf_url(p)
        arxiv_id = p.get('externalIds', {}).get('ArXiv')
        web_url = (
            f"https://arxiv.org/abs/{arxiv_id}" if arxiv_id
            else f"https://www.semanticscholar.org/paper/{p.get('paperId', '')}"
        )
        papers.append({
            'paper_id': p.get('paperId', ''),
            'title': p.get('title', ''),
            'authors': [a.get('name', '') for a in p.get('authors', [])],
            'abstract': (p.get('abstract') or '').replace('\n', ' '),
            'year': p.get('year'),
            'pdf_url': pdf_url,
            'web_url': web_url,
            'source': 'semantic_scholar',
            's2_id': p.get('paperId'),
            'full_text': None,
            'relevance_score': None
        })

    time.sleep(1.0)   # Polite delay after every S2 call
    return papers


# ── S2 ID resolution for arxiv papers ────────────────────────────────────────

@s2_retry(max_attempts=2, base_wait=2.0)
def _resolve_one_arxiv_to_s2(arxiv_id: str) -> Optional[str]:
    """Look up a paper's S2 ID using its arxiv ID."""
    url = f"https://api.semanticscholar.org/graph/v1/paper/arXiv:{arxiv_id}"
    response = requests.get(url, params={'fields': 'paperId'}, timeout=10)
    response.raise_for_status()
    return response.json().get('paperId')


def resolve_s2_ids(papers: List[Dict]) -> List[Dict]:
    """
    For any paper that has no s2_id but has an arxiv paper_id,
    query S2 to get the S2 ID. Needed so citation graph can follow references.
    Skips papers that already have an s2_id.
    """
    resolved = 0
    for paper in papers:
        if paper.get('s2_id'):
            continue
        arxiv_id = paper.get('paper_id', '')
        # arxiv IDs look like '2301.12345' or '2301.12345v1'
        if not arxiv_id or '.' not in arxiv_id:
            continue
        try:
            s2_id = _resolve_one_arxiv_to_s2(arxiv_id)
            if s2_id:
                paper['s2_id'] = s2_id
                resolved += 1
            time.sleep(0.5)
        except Exception:
            pass

    if resolved:
        print(f"  [S2 resolve] Resolved {resolved} arxiv → S2 IDs")
    return papers


# ── Deduplication ─────────────────────────────────────────────────────────────

def deduplicate_papers(papers: List[Dict]) -> List[Dict]:
    """
    Remove duplicate papers by normalised title.
    Prefers: arxiv > semantic_scholar (arxiv has more reliable PDFs).
    """
    seen: Dict[str, Dict] = {}
    for paper in papers:
        key = paper['title'].lower().strip()
        if not key:
            continue
        if key not in seen:
            seen[key] = paper
        elif paper['source'] == 'arxiv' and seen[key]['source'] != 'arxiv':
            seen[key] = paper
    return list(seen.values())


# ── PDF URL helper ────────────────────────────────────────────────────────────

def _resolve_pdf_url(p: dict) -> Optional[str]:
    if p.get('openAccessPdf'):
        url = p['openAccessPdf'].get('url')
        if url:
            return url
    arxiv_id = p.get('externalIds', {}).get('ArXiv')
    if arxiv_id:
        return f"https://arxiv.org/pdf/{arxiv_id}"
    return None
