"""
LangGraph Node Functions — v2

Node execution order:
  generate_queries → search_papers → rank_papers → read_papers
       → extract_structured → [conditional] follow_citations
       → extract_structured (citation round) → store_to_kb

Key fixes in v2:
  Node 1  — summarise → refine → queries + keywords
  Node 3  — rank all papers by relevance (abstract + smart PDF read)
             select top K → set papers_to_read
  Node 4  — full PDF read of top K only
  Node 5  — 3-tier extraction: forced JSON / field-by-field / abstract fallback
  Node 6  — always runs: S2 ID resolved for arxiv papers before seeding;
             title-based fallback if arxiv lookup fails
  Node 7  — stores with 150-250 word paragraph summary

Extraction strategy (why it failed before):
  llama3.2 sometimes ignores JSON instructions. Fix: pass format='json'
  to ollama, which forces the tokeniser to only produce valid JSON tokens.
  If the JSON is still malformed, fall back to field-by-field prompting.
  If that fails, produce a minimal record from title + abstract.
"""

import json
import time
from typing import List, Optional

import ollama

from state import ScoutState, Paper, ExtractedPaper
from tools.search import (
    search_arxiv, search_semantic_scholar,
    deduplicate_papers, resolve_s2_ids
)
from tools.pdf_reader import smart_read, full_read
from tools.citation_graph import get_references, resolve_s2_id_by_title
from knowledge_base import AerospaceKnowledgeBase

kb = AerospaceKnowledgeBase()

TOP_K = 10          # How many papers get full-read and deep extraction
CITE_SEEDS = 3      # How many papers seed the citation graph


# ════════════════════════════════════════════════════════════════════
#  NODE 1 — generate_queries
# ════════════════════════════════════════════════════════════════════

def generate_queries(state: ScoutState) -> dict:
    """
    Step 1: Summarise what the user is asking (show understanding).
    Step 2: Rewrite as a concise refined problem statement used downstream.
    Step 3: Extract domain keywords.
    Step 4: Generate 4 search queries from different angles.
    """
    problem = state['problem_statement']
    print(f"\n{'═'*60}")
    print("  NODE 1/7 — Understanding & Query Generation")
    print(f"{'─'*60}")

    # ── Step 1+2: Summarise + Refine ────────────────────────────────
    understand_prompt = f"""You are an aerospace research specialist. Read the following problem statement carefully.

Problem Statement:
{problem}

Your task has two parts — respond ONLY with a JSON object, no markdown, no preamble:

{{
  "problem_summary": "Write 3-4 sentences that demonstrate deep understanding of this problem: what is being optimised, what constraints apply, what makes this hard, and what domain it lives in.",
  "refined_problem": "Write ONE concise sentence (max 30 words) that captures the core technical challenge. This will be used as the search anchor.",
  "keywords": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5", "keyword6"]
}}

Keywords should be specific technical terms from the domain — not generic words like 'optimisation' alone."""

    summary_result = _llm_json(understand_prompt, fallback={
        'problem_summary': problem[:300],
        'refined_problem': problem[:100],
        'keywords': problem.split()[:6]
    })

    problem_summary = str(summary_result.get('problem_summary', problem[:200]))
    refined_problem = str(summary_result.get('refined_problem', problem[:80]))
    keywords = _ensure_list(summary_result.get('keywords', []))[:8]

    print(f"\n  Problem Summary:\n  {problem_summary[:200]}")
    print(f"\n  Refined Problem:\n  {refined_problem}")
    print(f"\n  Keywords: {', '.join(keywords)}")

    # ── Step 3: Generate 4 queries from different angles ─────────────
    query_prompt = f"""You are building a literature survey for this aerospace research problem:

Refined problem: {refined_problem}
Keywords: {', '.join(keywords)}

Generate exactly 4 search queries for academic databases. Each query must approach the problem from a DIFFERENT angle:
  Q1: Core technical terminology an expert in this field uses
  Q2: Methods / algorithms that solve this class of problem
  Q3: Aerospace / aviation / manufacturing domain context
  Q4: Analogous problem in a related field (robotics, logistics, civil engineering, operations research)

Respond ONLY with a JSON array of 4 strings:
["query one", "query two", "query three", "query four"]"""

    queries_raw = _llm_json(query_prompt, fallback=None)
    if isinstance(queries_raw, list) and len(queries_raw) >= 2:
        queries = [str(q).strip() for q in queries_raw if q][:5]
    else:
        queries = [
            refined_problem,
            f"{refined_problem} algorithm optimization",
            f"{refined_problem} aerospace manufacturing",
            f"{refined_problem} survey review state of the art"
        ]

    print(f"\n  Generated {len(queries)} queries:")
    for i, q in enumerate(queries, 1):
        print(f"    Q{i}: {q[:80]}")

    return {
        'problem_summary': problem_summary,
        'refined_problem': refined_problem,
        'keywords': keywords,
        'search_queries': queries,
        'messages': [
            f"Problem summarised and refined",
            f"Keywords: {', '.join(keywords)}",
            f"Generated {len(queries)} search queries"
        ]
    }


# ════════════════════════════════════════════════════════════════════
#  NODE 2 — search_papers
# ════════════════════════════════════════════════════════════════════

def search_papers(state: ScoutState) -> dict:
    """
    Search arxiv + Semantic Scholar for each query.
    Also runs one keyword-boosted search combining the top keywords.
    """
    queries = state['search_queries']
    keywords = state.get('keywords', [])
    all_papers: List[Paper] = []

    print(f"\n{'═'*60}")
    print("  NODE 2/7 — Searching arxiv + Semantic Scholar")
    print(f"{'─'*60}")

    # Per-query searches
    for i, query in enumerate(queries, 1):
        print(f"\n  Q{i}: {query[:65]}...")
        arxiv_res = search_arxiv(query, max_results=4)
        s2_res = search_semantic_scholar(query, max_results=4)
        print(f"    arxiv: {len(arxiv_res)}  S2: {len(s2_res)}")
        all_papers.extend(arxiv_res + s2_res)
        time.sleep(0.5)

    # Bonus keyword-combined search
    if keywords:
        kw_query = ' '.join(keywords[:4])
        print(f"\n  Keyword sweep: {kw_query[:65]}...")
        all_papers.extend(search_arxiv(kw_query, max_results=3))
        all_papers.extend(search_semantic_scholar(kw_query, max_results=3))

    unique = deduplicate_papers(all_papers)
    print(f"\n  Total: {len(all_papers)} → {len(unique)} unique after dedup")

    return {
        'raw_papers': unique,
        'papers_to_read': unique,
        'messages': [f"Search complete: {len(unique)} unique papers"]
    }


# ════════════════════════════════════════════════════════════════════
#  NODE 3 — rank_papers
# ════════════════════════════════════════════════════════════════════

def rank_papers(state: ScoutState) -> dict:
    """
    Two-step ranking:
      Pass A — Smart PDF read (first3 + middle + last2) for all papers
               that have a PDF URL. Abstract-only for the rest.
      Pass B — LLM scores each paper 1-10 against the refined problem.
      Select top TOP_K papers for full read.

    Also resolves arxiv → S2 IDs for papers that need them (critical for
    citation node). Does this now rather than later so the IDs are available
    when extract_structured runs.
    """
    papers = state.get('papers_to_read', [])
    refined = state.get('refined_problem', state['problem_statement'])
    keywords = state.get('keywords', [])

    print(f"\n{'═'*60}")
    print(f"  NODE 3/7 — Ranking {len(papers)} papers")
    print(f"{'─'*60}")

    # Pass A: quick read
    quick_texts = {}
    for p in papers:
        title_short = p['title'][:50]
        if p.get('pdf_url'):
            print(f"  Smart-read: {title_short}...")
            text = smart_read(p['pdf_url'])
            quick_texts[p['paper_id']] = text or p.get('abstract', '')
        else:
            quick_texts[p['paper_id']] = p.get('abstract', '')

    # Pass B: batch LLM scoring
    print(f"\n  Scoring {len(papers)} papers against refined problem...")
    scored = _batch_score(papers, quick_texts, refined, keywords)

    # Sort descending by score
    scored.sort(key=lambda x: x.get('relevance_score') or 0, reverse=True)

    top = scored[:TOP_K]
    print(f"\n  Top {len(top)} selected:")
    for p in top:
        print(f"    [{p.get('relevance_score', 0):.1f}] {p['title'][:60]}")

    # Resolve S2 IDs for arxiv papers (needed for citation graph)
    top = resolve_s2_ids(top)

    # Fallback: title-based S2 lookup for any that still lack s2_id
    for p in top:
        if not p.get('s2_id') and p.get('title'):
            try:
                sid = resolve_s2_id_by_title(p['title'])
                if sid:
                    p['s2_id'] = sid
                    print(f"  [S2 title-resolve] {p['title'][:50]} → {sid[:20]}")
            except Exception:
                pass

    return {
        'top_papers': top,
        'papers_to_read': top,
        'messages': [f"Ranked {len(papers)} papers → selected top {len(top)} for full read"]
    }


def _batch_score(papers, quick_texts, refined_problem, keywords) -> List[dict]:
    """
    Score all papers in a single LLM call to save time.
    Returns papers with relevance_score field populated.
    """
    lines = []
    for i, p in enumerate(papers):
        text = quick_texts.get(p['paper_id'], '')[:300]
        lines.append(f"{i+1}. Title: {p['title']}\n   Abstract: {text}")

    prompt = f"""Score these research papers by relevance to the problem below.

Problem: {refined_problem}
Keywords to look for: {', '.join(keywords[:6])}

Papers:
{chr(10).join(lines)}

Score each paper 1-10 where:
  10 = directly solves this exact class of problem
  7-9 = closely related method or domain
  4-6 = tangentially related
  1-3 = unrelated

Return ONLY a JSON array with one object per paper in the same order:
[{{"id": 1, "score": 8}}, {{"id": 2, "score": 5}}, ...]"""

    result = _llm_json(prompt, fallback=None)

    # Build score lookup
    score_map = {}
    if isinstance(result, list):
        for item in result:
            if isinstance(item, dict) and 'id' in item and 'score' in item:
                idx = int(item['id']) - 1
                if 0 <= idx < len(papers):
                    score_map[idx] = float(item.get('score', 5))

    # Apply scores
    scored = []
    for i, p in enumerate(papers):
        scored.append({**p, 'relevance_score': score_map.get(i, 5.0)})
    return scored


# ════════════════════════════════════════════════════════════════════
#  NODE 4 — read_papers
# ════════════════════════════════════════════════════════════════════

def read_papers(state: ScoutState) -> dict:
    """
    Full PDF read for the top-K papers selected by rank_papers.
    Falls back to abstract if PDF is unavailable.
    """
    papers = state.get('papers_to_read', [])

    print(f"\n{'═'*60}")
    print(f"  NODE 4/7 — Full-reading {len(papers)} papers")
    print(f"{'─'*60}")

    papers_read = []
    for p in papers:
        print(f"\n  → {p['title'][:60]}")
        if p.get('pdf_url'):
            text = full_read(p['pdf_url'])
            src = 'full PDF'
        else:
            text = p.get('abstract', '')
            src = 'abstract only'

        papers_read.append({**p, 'full_text': text or p.get('abstract', '')})
        chars = len(text) if text else len(p.get('abstract', ''))
        print(f"    ✓ {src} ({chars:,} chars)")

    return {
        'papers_read': papers_read,
        'messages': [f"Full-read {len(papers_read)} top papers"]
    }


# ════════════════════════════════════════════════════════════════════
#  NODE 5 — extract_structured
# ════════════════════════════════════════════════════════════════════

def extract_structured(state: ScoutState) -> dict:
    """
    3-tier extraction for each paper:
      Tier 1: format='json' + full schema prompt  (best quality)
      Tier 2: field-by-field individual prompts   (most reliable)
      Tier 3: abstract-only minimal record        (never fails)

    Also generates a 150-250 word paragraph summary for KB display.
    """
    papers_to_extract = state.get('papers_read', []) + state.get('citation_papers', [])
    already_done = {p['paper_id'] for p in state.get('extracted_papers', [])}
    pending = [p for p in papers_to_extract if p['paper_id'] not in already_done
               and (p.get('full_text') or p.get('abstract'))]

    print(f"\n{'═'*60}")
    print(f"  NODE 5/7 — Extracting from {len(pending)} papers")
    print(f"{'─'*60}")

    extracted = []
    citation_seeds = []

    for p in pending:
        print(f"\n  → {p['title'][:60]}")
        result = _extract_with_fallback(p)
        if result:
            extracted.append(result)
            print(f"    ✓ extracted")
            if p.get('s2_id') and state.get('citation_round', 0) == 0:
                citation_seeds.append(p['s2_id'])
        else:
            # Tier 3 always produces something
            result = _minimal_record(p)
            extracted.append(result)
            print(f"    ⚠ minimal record (abstract only)")

    print(f"\n  {len(extracted)}/{len(pending)} papers processed")

    return {
        'extracted_papers': extracted,
        'citation_seeds': citation_seeds,
        'messages': [f"Extraction: {len(extracted)}/{len(pending)} papers (round {state.get('citation_round', 0)})"]
    }


def _extract_with_fallback(paper: dict) -> Optional[ExtractedPaper]:
    """Try tier 1, then tier 2. Return None only if both fail (tier 3 in caller)."""
    text = paper.get('full_text') or paper.get('abstract') or ''

    # ── Tier 1: format='json' forced output ────────────────────────
    result = _tier1_extract(paper, text)
    if result:
        result['paper_summary'] = _generate_summary(paper, result)
        return result

    # ── Tier 2: field-by-field ──────────────────────────────────────
    print(f"    Tier 1 failed → trying field-by-field...")
    result = _tier2_extract(paper, text)
    if result:
        result['paper_summary'] = _generate_summary(paper, result)
        return result

    return None


def _tier1_extract(paper: dict, text: str) -> Optional[ExtractedPaper]:
    """
    Single-prompt extraction with format='json'.
    The format parameter forces the model to only output valid JSON tokens.
    """
    prompt = f"""Extract structured information from this research paper.
Return a JSON object with EXACTLY these fields:

{{
  "problem_addressed": "One sentence: what specific problem does this paper solve?",
  "proposed_method": "One sentence: what is the core approach or algorithm?",
  "key_assumptions": ["assumption 1 that must hold", "assumption 2", "assumption 3"],
  "results_metrics": "Key quantitative results. Use Not reported if absent.",
  "constraints": ["constraint limiting applicability", "constraint 2", "constraint 3"]
}}

Paper: {paper['title']}
Authors: {', '.join(paper.get('authors', [])[:3])} ({paper.get('year', 'unknown')})

Content:
{text[:5000]}"""

    try:
        response = ollama.chat(
            model='llama3.2',
            messages=[{'role': 'user', 'content': prompt}],
            format='json',                 # Forces valid JSON output
            options={'temperature': 0.05}
        )
        raw = response['message']['content'].strip()
        data = _parse_json_safely(raw, fallback=None)
        if not data or not isinstance(data, dict):
            return None
        return _assemble_extracted(paper, data)
    except Exception as e:
        print(f"    Tier 1 error: {e}")
        return None


def _tier2_extract(paper: dict, text: str) -> Optional[ExtractedPaper]:
    """
    Ask the LLM for each field individually with simple yes/no or
    open-ended prompts. Much more reliable than asking for full JSON at once.
    """
    context = f"Paper: {paper['title']}\n\nContent:\n{text[:3000]}"

    def ask(q: str, default: str) -> str:
        try:
            r = ollama.chat(
                model='llama3.2',
                messages=[{'role': 'user', 'content': f"{context}\n\nQuestion: {q}\nAnswer in 1-2 sentences only:"}],
                options={'temperature': 0.1}
            )
            return r['message']['content'].strip()[:300] or default
        except Exception:
            return default

    def ask_list(q: str) -> List[str]:
        try:
            r = ollama.chat(
                model='llama3.2',
                messages=[{'role': 'user', 'content': f"{context}\n\nQuestion: {q}\nList exactly 3 items, one per line, no bullets or numbers:"}],
                options={'temperature': 0.1}
            )
            lines = [l.strip() for l in r['message']['content'].strip().splitlines() if l.strip()]
            return lines[:3] or ['Not identified']
        except Exception:
            return ['Not identified']

    try:
        data = {
            'problem_addressed': ask("What specific problem does this paper address?", "Not specified"),
            'proposed_method': ask("What is the core method or algorithm proposed?", "Not specified"),
            'key_assumptions': ask_list("List 3 key assumptions the method requires to work."),
            'results_metrics': ask("What are the main quantitative results or metrics reported?", "Not reported"),
            'constraints': ask_list("List 3 constraints or limitations that restrict this method's applicability.")
        }
        return _assemble_extracted(paper, data)
    except Exception as e:
        print(f"    Tier 2 error: {e}")
        return None


def _minimal_record(paper: dict) -> ExtractedPaper:
    """Tier 3 — always succeeds. Uses abstract text only, no LLM."""
    abstract = paper.get('abstract', 'No abstract available.')
    return ExtractedPaper(
        paper_id=paper['paper_id'],
        title=paper['title'],
        authors=paper.get('authors', []),
        year=paper.get('year'),
        source=paper.get('source', ''),
        abstract=abstract,
        pdf_url=paper.get('pdf_url'),
        web_url=paper.get('web_url'),
        problem_addressed=abstract[:200],
        proposed_method='See abstract — LLM extraction unavailable',
        key_assumptions=['See paper directly'],
        results_metrics='See paper directly',
        constraints=['See paper directly'],
        paper_summary=f"**{paper['title']}** ({paper.get('year', 'n.d.')}). {abstract[:400]}"
    )


def _assemble_extracted(paper: dict, data: dict) -> Optional[ExtractedPaper]:
    """Build ExtractedPaper from paper metadata + extracted dict."""
    required = ['problem_addressed', 'proposed_method', 'key_assumptions',
                'results_metrics', 'constraints']
    if not all(k in data for k in required):
        return None
    try:
        return ExtractedPaper(
            paper_id=paper['paper_id'],
            title=paper['title'],
            authors=paper.get('authors', []),
            year=paper.get('year'),
            source=paper.get('source', ''),
            abstract=paper.get('abstract', ''),
            pdf_url=paper.get('pdf_url'),
            web_url=paper.get('web_url'),
            problem_addressed=str(data['problem_addressed']),
            proposed_method=str(data['proposed_method']),
            key_assumptions=_ensure_list(data['key_assumptions']),
            results_metrics=str(data['results_metrics']),
            constraints=_ensure_list(data['constraints']),
            paper_summary=''   # Filled by caller
        )
    except Exception:
        return None


def _generate_summary(paper: dict, extracted: ExtractedPaper) -> str:
    """
    Generate a 150-250 word paragraph about the paper for KB display.
    Uses the already-extracted structured fields rather than re-reading the full text.
    """
    prompt = f"""Write a 150-250 word paragraph that a researcher would read to quickly understand this paper.
Include: what problem it solves, the core method used, key results, and any important limitations.
Write in third person, past tense. Be specific and technical.

Title: {extracted['title']}
Year: {extracted.get('year', 'unknown')}
Problem: {extracted['problem_addressed']}
Method: {extracted['proposed_method']}
Results: {extracted['results_metrics']}
Constraints: {', '.join(extracted.get('constraints', [])[:3])}
Abstract: {paper.get('abstract', '')[:400]}

Write only the paragraph. No title, no bullet points, no headers."""

    try:
        response = ollama.chat(
            model='llama3.2',
            messages=[{'role': 'user', 'content': prompt}],
            options={'temperature': 0.3}
        )
        summary = response['message']['content'].strip()
        # Ensure it's in range
        words = summary.split()
        if len(words) > 260:
            summary = ' '.join(words[:250]) + '...'
        return summary
    except Exception:
        # Fallback: compose from fields
        return (
            f"{extracted['title']} ({extracted.get('year', 'n.d.')}) addresses "
            f"{extracted['problem_addressed']} The authors propose "
            f"{extracted['proposed_method']} "
            f"Results: {extracted['results_metrics']} "
            f"Limitations include: {'; '.join(extracted.get('constraints', [])[:2])}."
        )


# ════════════════════════════════════════════════════════════════════
#  NODE 6 — follow_citations
# ════════════════════════════════════════════════════════════════════

def follow_citations(state: ScoutState) -> dict:
    """
    Follow the reference lists of top papers to find foundational work.

    v2 fixes:
      - citation_seeds comes from extract_structured (S2 IDs of top papers)
      - S2 IDs were resolved in rank_papers so this should always have seeds
      - Prints why it's skipping if seeds are still empty
      - citation_papers get full_text from smart_read (not inline full_read)
        to keep this node fast — they'll go through extract_structured next
    """
    seeds = state.get('citation_seeds', [])[:CITE_SEEDS]
    seen_ids = {p['paper_id'] for p in state.get('raw_papers', [])}

    print(f"\n{'═'*60}")
    print(f"  NODE 6/7 — Citation Graph ({len(seeds)} seeds)")
    print(f"{'─'*60}")

    if not seeds:
        print("  ⚠ No seeds available — check that S2 IDs were resolved in rank_papers")
        print("    Papers without s2_id cannot seed citation graph")
        return {
            'citation_papers': [],
            'citation_round': state.get('citation_round', 0) + 1,
            'messages': ["Citation graph: 0 seeds available (no S2 IDs resolved)"]
        }

    citation_papers = []
    for s2_id in seeds:
        print(f"\n  Following references of seed: {s2_id[:30]}...")
        refs = get_references(s2_id, limit=6)
        print(f"    Got {len(refs)} references")

        for ref in refs:
            if not ref['paper_id'] or ref['paper_id'] in seen_ids:
                continue
            seen_ids.add(ref['paper_id'])

            # Smart read for citation papers (fast, good enough for extraction)
            if ref.get('pdf_url'):
                text = smart_read(ref['pdf_url'])
                ref['full_text'] = text or ref.get('abstract', '')
            else:
                ref['full_text'] = ref.get('abstract', '')

            citation_papers.append(ref)
            print(f"    + {ref['title'][:60]}")

    print(f"\n  Total new citation papers: {len(citation_papers)}")

    return {
        'citation_papers': citation_papers,
        'citation_round': state.get('citation_round', 0) + 1,
        'messages': [f"Citation graph: {len(citation_papers)} foundational papers from {len(seeds)} seeds"]
    }


# ════════════════════════════════════════════════════════════════════
#  NODE 7 — store_to_kb
# ════════════════════════════════════════════════════════════════════

def store_to_kb(state: ScoutState) -> dict:
    """Write all extracted papers to ChromaDB. Upsert = idempotent."""
    papers = state.get('extracted_papers', [])

    print(f"\n{'═'*60}")
    print(f"  NODE 7/7 — Storing {len(papers)} papers to ChromaDB")
    print(f"{'─'*60}")

    stored = kb.store_papers_batch(papers)

    print(f"  ✓ Stored: {stored}/{len(papers)}")
    print(f"  ✓ Total in KB: {kb.count()}")

    return {
        'stored_count': stored,
        'messages': [f"ChromaDB: {stored}/{len(papers)} stored (total: {kb.count()})"]
    }


# ════════════════════════════════════════════════════════════════════
#  Utilities
# ════════════════════════════════════════════════════════════════════

def _llm_json(prompt: str, fallback):
    """
    Call llama3.2 with format='json' and parse the result.
    Falls back to manual JSON extraction if parsing still fails.
    """
    try:
        response = ollama.chat(
            model='llama3.2',
            messages=[{'role': 'user', 'content': prompt}],
            format='json',
            options={'temperature': 0.1}
        )
        raw = response['message']['content'].strip()
        return _parse_json_safely(raw, fallback)
    except Exception as e:
        print(f"  [LLM] Error: {e}")
        return fallback


def _parse_json_safely(text: str, fallback):
    """Try multiple strategies to extract JSON from LLM output."""
    if not text:
        return fallback

    # Strip markdown fences
    if '```' in text:
        for part in text.split('```'):
            part = part.strip().lstrip('json').strip()
            try:
                return json.loads(part)
            except json.JSONDecodeError:
                continue

    # Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Find JSON boundaries
    for start_char, end_char in [('{', '}'), ('[', ']')]:
        if start_char in text:
            try:
                s = text.index(start_char)
                e = text.rindex(end_char) + 1
                return json.loads(text[s:e])
            except (ValueError, json.JSONDecodeError):
                continue

    return fallback


def _ensure_list(value) -> List[str]:
    if isinstance(value, list):
        return [str(i) for i in value if i]
    if isinstance(value, str):
        return [value]
    return []
