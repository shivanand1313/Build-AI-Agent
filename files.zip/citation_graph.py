"""
Citation Graph — v2

Uses S2 references (backward citations) to find foundational work.
Retry decorator handles 429 and 5xx the same way as search.py.

New in v2:
  resolve_s2_id_by_title() — fallback for papers where arxiv ID lookup fails
"""

import time
import requests
from typing import List, Dict, Optional

from tools.search import s2_retry

BASE_URL = "https://api.semanticscholar.org/graph/v1/paper"
FIELDS = "paperId,title,authors,year,abstract,openAccessPdf,externalIds"


# ── Main API ─────────────────────────────────────────────────────────────────

@s2_retry(max_attempts=3, base_wait=2.0)
def get_references(s2_paper_id: str, limit: int = 8) -> List[Dict]:
    """
    Fetch papers cited by this paper (its reference list).
    These are upstream foundational papers — highest value for surveys.
    """
    url = f"{BASE_URL}/{s2_paper_id}/references"
    response = requests.get(url, params={'fields': FIELDS, 'limit': limit}, timeout=15)
    response.raise_for_status()
    data = response.json()

    papers = []
    for item in data.get('data', []):
        p = item.get('citedPaper', {})
        if not p.get('paperId') or not p.get('title'):
            continue

        pdf_url, web_url = _resolve_urls(p)
        papers.append({
            'paper_id': p.get('paperId', ''),
            'title': p.get('title', ''),
            'authors': [a.get('name', '') for a in p.get('authors', [])],
            'abstract': (p.get('abstract') or '').replace('\n', ' '),
            'year': p.get('year'),
            'pdf_url': pdf_url,
            'web_url': web_url,
            'source': 'semantic_scholar_reference',
            's2_id': p.get('paperId'),
            'full_text': None,
            'relevance_score': None
        })

    time.sleep(1.0)
    return papers


@s2_retry(max_attempts=2, base_wait=2.0)
def resolve_s2_id_by_title(title: str) -> Optional[str]:
    """
    Last-resort S2 ID lookup by paper title.
    Used when arxiv ID resolution fails.
    """
    url = f"{BASE_URL}/search"
    params = {'query': title, 'limit': 1, 'fields': 'paperId,title'}
    response = requests.get(url, params=params, timeout=10)
    response.raise_for_status()
    data = response.json()

    candidates = data.get('data', [])
    if not candidates:
        return None

    # Only accept if title matches closely
    result_title = candidates[0].get('title', '').lower()
    query_title = title.lower()
    # Simple overlap check — avoid false positives
    overlap = len(set(query_title.split()) & set(result_title.split()))
    if overlap >= min(4, len(query_title.split())):
        return candidates[0].get('paperId')
    return None


# ── URL helpers ───────────────────────────────────────────────────────────────

def _resolve_urls(p: dict):
    """Return (pdf_url, web_url) tuple for a S2 paper dict."""
    pdf_url = None
    if p.get('openAccessPdf'):
        pdf_url = p['openAccessPdf'].get('url')

    arxiv_id = p.get('externalIds', {}).get('ArXiv')
    if not pdf_url and arxiv_id:
        pdf_url = f"https://arxiv.org/pdf/{arxiv_id}"

    if arxiv_id:
        web_url = f"https://arxiv.org/abs/{arxiv_id}"
    else:
        s2_id = p.get('paperId', '')
        web_url = f"https://www.semanticscholar.org/paper/{s2_id}" if s2_id else None

    return pdf_url, web_url
