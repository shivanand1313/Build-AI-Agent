"""
LangGraph graph — v2

New node: rank_papers (between search_papers and read_papers)

Full topology:
  START
    → generate_queries          (summarise + refine + queries + keywords)
    → search_papers             (arxiv + S2, all queries)
    → rank_papers               (smart read all, score, select top K, resolve S2 IDs)
    → read_papers               (full read of top K only)
    → extract_structured        (3-tier extraction + paragraph summary)
    → [conditional]
         citation_round == 0 AND seeds exist → follow_citations
                                               → extract_structured   (citation papers)
                                               → store_to_kb
         otherwise             → store_to_kb
    → END
"""

from langgraph.graph import StateGraph, START, END

from state import ScoutState
from nodes import (
    generate_queries,
    search_papers,
    rank_papers,
    read_papers,
    extract_structured,
    follow_citations,
    store_to_kb
)


def route_after_extraction(state: ScoutState) -> str:
    """
    Conditional edge — runs after extract_structured completes.

    Routes to follow_citations ONLY on first pass when seeds exist.
    citation_round == 0 means follow_citations hasn't run yet.
    """
    is_first_round = state.get('citation_round', 0) == 0
    has_seeds = bool(state.get('citation_seeds'))

    if is_first_round and has_seeds:
        print(f"\n  [Router] citation_round=0, {len(state['citation_seeds'])} seeds → follow_citations")
        return "follow_citations"

    reason = "no seeds" if not has_seeds else "citation_round=1"
    print(f"\n  [Router] {reason} → store_to_kb")
    return "store_to_kb"


def build_scout_graph():
    builder = StateGraph(ScoutState)

    # ── Nodes ──────────────────────────────────────────────────────
    builder.add_node("generate_queries",   generate_queries)
    builder.add_node("search_papers",      search_papers)
    builder.add_node("rank_papers",        rank_papers)     # NEW in v2
    builder.add_node("read_papers",        read_papers)
    builder.add_node("extract_structured", extract_structured)
    builder.add_node("follow_citations",   follow_citations)
    builder.add_node("store_to_kb",        store_to_kb)

    # ── Edges ──────────────────────────────────────────────────────
    builder.add_edge(START,              "generate_queries")
    builder.add_edge("generate_queries", "search_papers")
    builder.add_edge("search_papers",    "rank_papers")
    builder.add_edge("rank_papers",      "read_papers")
    builder.add_edge("read_papers",      "extract_structured")

    builder.add_conditional_edges(
        "extract_structured",
        route_after_extraction,
        {
            "follow_citations": "follow_citations",
            "store_to_kb":      "store_to_kb"
        }
    )

    # After citations are fetched, extract them with the same node
    builder.add_edge("follow_citations", "extract_structured")
    builder.add_edge("store_to_kb",      END)

    return builder.compile()
